<?php
// Process the feedback form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $feedback = htmlspecialchars($_POST['feedback']);

    // Example: Send the feedback to an email or save to database
    // For now, we are just displaying the feedback data

    echo "<div class='alert alert-success mt-4'>Thank you, $name! Your feedback has been received.</div>";
    // Optionally, store feedback in a database here.
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel = "stylesheet" href="../css/general.css">
    <!-- Custom CSS -->

</head>
<body>
<div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h3>Navigation</h3>
            <a href="../index.php">home</a>
            <a href="create_cv.php">Create CV</a>
            <a href="#">Contact</a>
            <a href="skills_progression.php">Skills Progression</a>
            <a href="aboutus.php">About Us</a>
            <a href="logout.php">Logout</a>
        </div>

        <!-- Main Content Area -->
    <div class="main-content">
    <h2 class="text-center text-primary mb-4">Contact Us</h2>

    <!-- Contact Information Section -->
    <div class="contact-info mb-4">
        <h4>Our Contact Information</h4>
        <p><strong>Address:</strong> Pelttarinkatu B4 32, 20610, Turku</p>
        <p><strong>Phone:</strong> 0412768962</p>
        <p><strong>Email:</strong> <a href="mailto:info@example.com">muniir4910@gmail.com</a></p>
    </div>

    <!-- Feedback Form -->
    <div class="feedback-form">
        <h4>Leave Us Feedback</h4>
        <form action="contact.php" method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>

            <div class="mb-3">
                <label for="feedback" class="form-label">Your Feedback</label>
                <textarea class="form-control" id="feedback" name="feedback" rows="4" required></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Submit Feedback</button>
        </form>
    </div>
</div>
</div>

<footer class="footer">
        <p>&copy; 2024 CV Builder. All rights reserved. Mohamed Osman Abdi</p>
        <div class="footer-icons">
            <a href="https://github.com/turkuai/web-cv-team-4">Github</a>
            <a href="#">Twitter</a>
            <a href="#">Link</a>
            <a href="#">Discord</a>
        </div>
</footer>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
