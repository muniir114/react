<?php
session_start();
include 'db.php'; // Include your database connection file

// Check if the user is logged in as an admin
if (isset($_SESSION['admin_id'])) {
    header('Location: login.php'); // Redirect to login if not logged in as admin
    exit();
}

// Handle Delete User Action
if (isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    header('Location: admin.php'); // Redirect back after deletion
    exit();
}

// Handle Delete Application Action
if (isset($_POST['delete_application'])) {
    $application_id = $_POST['application_id'];
    $stmt = $conn->prepare("DELETE FROM cvs WHERE id = ?");
    $stmt->bind_param('i', $application_id);
    $stmt->execute();
    header('Location: admin.php'); // Redirect back after deletion
    exit();
}

// Pagination and Search Logic for Users
$limit = 10;  // Number of records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start_from = ($page - 1) * $limit;

// Get total number of users
$total_users = $conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0];
$total_pages_users = ceil($total_users / $limit);

// Search query for users
$search_user = '';
if (isset($_GET['search_user'])) {
    $search_user = $_GET['search_user'];
    $users = $conn->query("SELECT * FROM users WHERE name LIKE '%$search_user%' OR email LIKE '%$search_user%' LIMIT $start_from, $limit");
} else {
    $users = $conn->query("SELECT * FROM users LIMIT $start_from, $limit");
}

// Pagination and Search Logic for Applications
$total_apps = $conn->query("SELECT COUNT(*) FROM cvs")->fetch_row()[0];
$total_pages_apps = ceil($total_apps / $limit);

// Search query for applications
$search_application = '';
if (isset($_GET['search_application'])) {
    $search_application = $_GET['search_application'];
    $applications = $conn->query("SELECT * FROM cvs WHERE name LIKE '%$search_application%' OR name LIKE '%$search_application%' LIMIT $start_from, $limit");
} else {
    $applications = $conn->query("SELECT * FROM cvs LIMIT $start_from, $limit");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS (Optional for further customizations) -->
    <style>
        body {
            background-color: #f8f9fa;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .pagination {
            justify-content: center;
        }
        .modal-header, .modal-footer {
            border: none;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <h2 class="text-center text-primary">Admin Dashboard</h2>

        <!-- Search Users -->
        <div class="mb-4">
            <h3>User Management</h3>
            <form id="userSearchForm" class="d-flex mb-3">
                <input type="text" id="search_user" value="<?php echo htmlspecialchars($search_user); ?>" placeholder="Search users by name or email" class="form-control me-2">
                <button type="submit" class="btn btn-primary">Search</button>
            </form>
            
            <!-- User Table -->
            <table class="table table-striped table-bordered" id="userTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($user = $users->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['name']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <!-- Delete User Modal Trigger -->
                                <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteUserModal<?php echo $user['id']; ?>">Delete</button>
                                <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-warning btn-sm">Edit</a> |
                                <a href="view_user.php?id=<?php echo $user['id']; ?>" class="btn btn-info btn-sm">View</a>
                            </td>
                        </tr>

                        <!-- Delete User Modal -->
                        <div class="modal fade" id="deleteUserModal<?php echo $user['id']; ?>" tabindex="-1" aria-labelledby="deleteUserModalLabel<?php echo $user['id']; ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="deleteUserModalLabel<?php echo $user['id']; ?>">Confirm Deletion</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Are you sure you want to delete this user?
                                    </div>
                                    <div class="modal-footer">
                                        <form action="admin.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <button type="submit" name="delete_user" class="btn btn-danger">Delete</button>
                                        </form>
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </tbody>
            </table>

            <!-- Pagination for Users -->
            <nav>
                <ul class="pagination">
                    <li class="page-item <?php echo ($page == 1) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="admin.php?page=<?php echo $page - 1; ?>&search_user=<?php echo $search_user; ?>">Previous</a>
                    </li>
                    <li class="page-item <?php echo ($page == $total_pages_users) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="admin.php?page=<?php echo $page + 1; ?>&search_user=<?php echo $search_user; ?>">Next</a>
                    </li>
                </ul>
            </nav>
        </div>

        <!-- Search Applications -->
        <div class="mb-4">
            <h3>Application Management</h3>
            <form id="applicationSearchForm" class="d-flex mb-3">
                <input type="text" id="search_application" value="<?php echo htmlspecialchars($search_application); ?>" placeholder="Search applications by name" class="form-control me-2">
                <button type="submit" class="btn btn-primary">Search</button>
            </form>

            <!-- Application Table -->
            <table class="table table-striped table-bordered" id="applicationTable">
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>CV Details</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($application = $applications->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($application['user_id']); ?></td>
                            <td>
                                <a href="create_cv.php?id=<?php echo $application['id']; ?>">
                                    <?php echo htmlspecialchars($application['name']); ?>
                                </a>
                            </td>
                            <td>
                                <!-- Delete Application Modal Trigger -->
                                <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteApplicationModal<?php echo $application['id']; ?>">Delete</button>
                                <a href="edit_application.php?id=<?php echo $application['id']; ?>" class="btn btn-warning btn-sm">Edit</a> |
                                <a href="view_application.php?id=<?php echo $application['id']; ?>" class="btn btn-info btn-sm">View</a>
                            </td>
                        </tr>

                        <!-- Delete Application Modal -->
                        <div class="modal fade" id="deleteApplicationModal<?php echo $application['id']; ?>" tabindex="-1" aria-labelledby="deleteApplicationModalLabel<?php echo $application['id']; ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="deleteApplicationModalLabel<?php echo $application['id']; ?>">Confirm Deletion</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Are you sure you want to delete this application?
                                    </div>
                                    <div class="modal-footer">
                                        <form action="admin.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="application_id" value="<?php echo $application['id']; ?>">
                                            <button type="submit" name="delete_application" class="btn btn-danger">Delete</button>
                                        </form>
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </tbody>
            </table>

            <!-- Pagination for Applications -->
            <nav>
                <ul class="pagination">
                    <li class="page-item <?php echo ($page == 1) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="admin.php?page=<?php echo $page - 1; ?>&search_application=<?php echo $search_application; ?>">Previous</a>
                    </li>
                    <li class="page-item <?php echo ($page == $total_pages_apps) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="admin.php?page=<?php echo $page + 1; ?>&search_application=<?php echo $search_application; ?>">Next</a>
                    </li>
                </ul>
            </nav>
        </div>

        <!-- Add New User and Application -->
        <h3>Actions</h3>
        <ul>
            <li><a href="add_user.php" class="btn btn-success">Add New User</a></li>
            <li><a href="add_application.php" class="btn btn-success">Add New Application</a></li>
        </ul>
    </div>

    <!-- Bootstrap JS (Required for modal functionality) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- JavaScript for Dynamic Search -->
    <script>
        document.getElementById("userSearchForm").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent the form from submitting the traditional way
            const searchQuery = document.getElementById("search_user").value;

            fetch(`admin.php?search_user=${searchQuery}`)
                .then(response => response.text())
                .then(html => {
                    document.getElementById("userTable").innerHTML = html;
                });
        });

        document.getElementById("applicationSearchForm").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent the form from submitting the traditional way
            const searchQuery = document.getElementById("search_application").value;

            fetch(`admin.php?search_application=${searchQuery}`)
                .then(response => response.text())
                .then(html => {
                    document.getElementById("applicationTable").innerHTML = html;
                });
        });
    </script>
</body>
</html>

