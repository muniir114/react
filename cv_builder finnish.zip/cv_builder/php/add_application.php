<?php
session_start();
include 'db.php'; // Include the database connection
/*
// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
*/

$user_id = $_SESSION['user_id'];  // Retrieve user_id from session

// Handle form submission to save CV details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate input
    $name = htmlspecialchars($_POST['name']);
    $phone_number = htmlspecialchars($_POST['phone_number']);
    $address = htmlspecialchars($_POST['address']);
    $email = htmlspecialchars($_POST['email']);
    $experience = htmlspecialchars($_POST['experience']);
    $hobbies = htmlspecialchars($_POST['hobbies']);
    $languages = htmlspecialchars($_POST['languages']);

    // Education inputs (arrays for multiple records)
    $school_names = $_POST['school_name'];
    $start_dates = $_POST['start_date'];
    $end_dates = $_POST['end_date'];
    $departments = $_POST['department'];
    $descriptions = $_POST['description'];

    $conn->begin_transaction(); // Start a transaction
    try {
        // Insert CV data
        $stmt = $conn->prepare("INSERT INTO cvs (user_id, name, phone_number, address, email, experience, hobbies, languages profile_picture) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssssss", $user_id, $name,  $phone_number, $address, $email, $experience, $hobbies, $languages, $profile_picture);

        if (!$stmt->execute()) {
            throw new Exception("Error inserting CV: " . $stmt->error);
        }

        $cv_id = $conn->insert_id; // Get the generated CV ID

        // Insert education records
        $edu_stmt = $conn->prepare("INSERT INTO education (cv_id, school_name, start_date, end_date, department, description) 
                                    VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($school_names as $index => $school_name) {
            $start_date = $start_dates[$index];
            $end_date = $end_dates[$index];
            $department = $departments[$index];
            $description = $descriptions[$index];

            $edu_stmt->bind_param("isssss", $cv_id, $school_name, $start_date, $end_date, $department, $description);
            if (!$edu_stmt->execute()) {
                throw new Exception("Error inserting education: " . $edu_stmt->error);
            }
        }

        $conn->commit(); // Commit the transaction
        echo "CV saved successfully!";
    } catch (Exception $e) {
        $conn->rollback(); // Rollback the transaction on error
        echo $e->getMessage();
    }
}

// Fetch existing CV and education data for pre-filling (optional)
$result = $conn->query("SELECT * FROM cvs WHERE user_id='$user_id'");
$cv = $result->fetch_assoc();

$educations = [];
if ($cv) {
    $cv_id = $cv['id'];
    $edu_result = $conn->query("SELECT * FROM education WHERE cv_id='$cv_id'");
    while ($edu = $edu_result->fetch_assoc()) {
        $educations[] = $edu;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if a file was uploaded
    if (isset($_FILES['cv_picture']) && $_FILES['cv_picture']['error'] === UPLOAD_ERR_OK) {
        $image_tmp = $_FILES['cv_picture']['tmp_name'];
        $image_name = $_FILES['cv_picture']['name'];
        $image_size = $_FILES['cv_picture']['size'];
        $image_ext = pathinfo($image_name, PATHINFO_EXTENSION);

        // Allowed image types
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

        // Check if the uploaded file is an allowed type
        if (in_array(strtolower($image_ext), $allowed_types)) {
            // Generate a unique name for the image to avoid conflicts
            $new_image_name = 'cv_picture_' . time() . '.' . $image_ext;
            $image_path = 'uploads/' . $new_image_name;

            // Move the uploaded file to the desired folder
            if (move_uploaded_file($image_tmp, $image_path)) {
                // Store the image path in your database (assuming other form fields are also processed)
                // Modify the SQL insert query to include the image path
                $stmt = $mysqli->prepare("INSERT INTO your_table (column1, column2, image_path) VALUES (?, ?, ?)");
                $stmt->bind_param('iss', 1, 'other_value', $image_path);
                $stmt->execute();
            } else {
                echo "Error uploading the image.";
            }
        } else {
            echo "Invalid image type.";
        }
    }
}


$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Resume</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            background-color: #ffffff;
            padding: 20px;
            margin-top: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Generate Resume</h2>

    <!-- Resume Form -->
    <form action="generate_resume.php" method="POST" id="resumeForm" enctype="multipart/form-data">
        <!-- Personal Information -->
        <div class="mb-3">
            <label for="name" class="form-label"> Name:</label>
            <input type="text" class="form-control" name="name" id="name" value="<?php echo isset($cv['name']) ? htmlspecialchars($cv['name']) : ''; ?>" required>
        </div>
        <div class="mb-3">
            <label for="phone_number" class="form-label">Phone Number:</label>
            <input type="text" class="form-control" name="phone_number" id="phone_number" value="<?php echo isset($cv['phone_number']) ? htmlspecialchars($cv['phone_number']) : ''; ?>">
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Address:</label>
            <textarea class="form-control" name="address" id="address"><?php echo isset($cv['address']) ? htmlspecialchars($cv['address']) : ''; ?></textarea>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email:</label>
            <input type="email" class="form-control" name="email" id="email" value="<?php echo isset($cv['email']) ? htmlspecialchars($cv['email']) : ''; ?>">
        </div>

        <!-- Experience, Hobbies, Languages (add more fields as needed) -->
        <div class="mb-3">
            <label for="experience" class="form-label">Experience:</label>
            <textarea class="form-control" name="experience"><?php echo isset($cv['experience']) ? htmlspecialchars($cv['experience']) : ''; ?></textarea>
        </div>
        <div class="mb-3">
            <label for="hobbies" class="form-label">Hobbies:</label>
            <textarea class="form-control" name="hobbies"><?php echo isset($cv['hobbies']) ? htmlspecialchars($cv['hobbies']) : ''; ?></textarea>
        </div>
        <div class="mb-3">
            <label for="languages" class="form-label">Languages:</label>
            <textarea class="form-control" name="languages"><?php echo isset($cv['languages']) ? htmlspecialchars($cv['languages']) : ''; ?></textarea>
        </div>

        <!-- Education Section -->
        <div id="education-section">
            <h3>Education</h3>
            <?php if ($educations): ?>
                <?php foreach ($educations as $education): ?>
                    <div class="education-entry">
                        <input type="text" class="form-control mb-2" name="school_name[]" value="<?php echo htmlspecialchars($education['school_name']); ?>" required>
                        <input type="date" class="form-control mb-2" name="start_date[]" value="<?php echo htmlspecialchars($education['start_date']); ?>" required>
                        <input type="date" class="form-control mb-2" name="end_date[]" value="<?php echo htmlspecialchars($education['end_date']); ?>" required>
                        <input type="text" class="form-control mb-2" name="department[]" value="<?php echo htmlspecialchars($education['department']); ?>" required>
                        <textarea class="form-control mb-2" name="description[]"><?php echo htmlspecialchars($education['description']); ?></textarea>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="education-entry">
                    <input type="text" class="form-control mb-2" name="school_name[]" placeholder="School Name" required>
                    <input type="date" class="form-control mb-2" name="start_date[]" required>
                    <input type="date" class="form-control mb-2" name="end_date[]" required>
                    <input type="text" class="form-control mb-2" name="department[]" placeholder="Department" required>
                    <textarea class="form-control mb-2" name="description[]"></textarea>
                </div>
            <?php endif; ?>
        </div>
        <button type="button" class="btn btn-secondary mt-3" id="add-education">Add Another Education</button>

        <button type="submit" class="btn btn-primary mt-3">Save Resume</button>
        <button type="submit" name="generate_pdf" class="btn btn-success mt-3">Generate PDF</button>
        
        
    </form>
    </div>
    
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        // Add education entry
        $("#add-education").click(function () {
            $("#education-section").append(`
                <div class="education-entry">
                    <input type="text" class="form-control mb-2" name="school_name[]" placeholder="School Name" required>
                    <input type="date" class="form-control mb-2" name="start_date[]" required>
                    <input type="date" class="form-control mb-2" name="end_date[]" required>
                    <input type="text" class="form-control mb-2" name="department[]" placeholder="Department" required>
                    <textarea class="form-control mb-2" name="description[]"></textarea>
                    <button type="button" class="btn btn-danger mt-2 remove-education">Remove</button>
                </div>
            `);
        });

        // Remove education entry
        $(document).on("click", ".remove-education", function () {
            $(this).closest(".education-entry").remove();
        });
    });
</script>
</body>
</html>

