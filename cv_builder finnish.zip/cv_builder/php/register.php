<?php
// Database connection
include 'db.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password

    // SQL query to insert the new user
    $sql = "INSERT INTO users (name, email, username, password) VALUES ('$name', '$email', '$username', '$password')";
    
    if ($conn->query($sql) === TRUE) {
        // Redirect to login page after successful registration
        header('Location: login.php');
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            height: 100vh;
        }

        .register-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }

        .register-form {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .register-form h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #007bff;
        }

        .form-control {
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            background-color: #007bff;
            color: white;
            border: none;
            font-size: 16px;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-top: 15px;
        }

        .footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 15px;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<div class="register-container">
    <div class="register-form">
        <h2>Create New Account</h2>

        <!-- Registration Form -->
        <form action="register.php" method="POST" id="registerForm">
            <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input type="text" id="name" name="name" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" id="email" name="email" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" id="username" name="username" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>

            <button type="submit" class="btn">Submit</button>
        </form>
        
        <!-- Error message display -->
        <?php if (isset($error)) echo "<p class='error-message'>$error</p>"; ?>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    <p>&copy; 2024 CV Builder. All rights reserved.</p>
</div>

<!-- Bootstrap JS (Popper.js and Bootstrap JS) -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>

<!-- Custom JS for Form Validation -->
<script>
    document.getElementById("registerForm").addEventListener("submit", function(event) {
        var name = document.getElementById("name").value.trim();
        var email = document.getElementById("email").value.trim();
        var username = document.getElementById("username").value.trim();
        var password = document.getElementById("password").value.trim();

        if (name === "" || email === "" || username === "" || password === "") {
            event.preventDefault();
            alert("All fields are required.");
        }
    });
</script>

</body>
</html>
