<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .about-us {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .team-member {
            margin-top: 30px;
        }
        .team-member img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
        }
    </style>
</head>
<body>

<div class="container">

    <h2 class="text-center text-primary mb-4">About Us</h2>

    <div class="about-us">
        <h4>Our Story</h4>
        <p>We are a team of passionate students with couple years of exprience, who are dedicated to help people with a simple CV Website.</p>
        <p>Our CV Website is for students & people who are need of a simple CV Which gives a positive message to their future employers</p>
        <P2>This Page has everything what you need, calling out Skill Progression</p2>

    
        <h4>Our Team</h4>
        
        <div class="row team-member">
            <div class="col-md-4 text-center">
                <img src="img_12.jpeg" alt="Team Member">
                <h5>Mohamed Osman Abdi</h5>
                <p>Full-Stack Developer</p>
                <p2>Phone Number - +3580000000</p2>
            </div>
            <div class="col-md-4 text-center">
                <img src="https://via.placeholder.com/150" alt="Team Member">
                <h5>Mohammed Alyasin</h5>
                <p>Front-End Web Developer</p>
                <p2>Phone Number - +3580000000</p2>
            </div>
            <div class="col-md-4 text-center">
                <img src="https://via.placeholder.com/150" alt="Team Member">
                <h5>Artturi Nurmi</h5>
                <p>Front-End Web Developer</p>
                <p2>Phone Number - +3580000000</p2>
            </div>
            <div class="col-md-4 text-center">
                <img src="https://via.placeholder.com/150" alt="Team Member">
                <h5>Luukas Laurila</h5>
                <p>Front-End Web Developer</p>
                <p2>Phone Number - +3580000000</p2>
            </div>
        </div>
    </div>

</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
