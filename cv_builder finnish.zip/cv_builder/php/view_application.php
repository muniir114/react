<?php
session_start();
include 'db.php';

// Get application ID from URL
if (isset($_GET['id'])) {
    $application_id = $_GET['id'];

    // Fetch application data from the database
    $stmt = $conn->prepare("SELECT * FROM cvs WHERE id = ?");
    $stmt->bind_param('i', $application_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $application = $result->fetch_assoc();
    } else {
        $error_message = "Application not found!";
        exit();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Application</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
        }
        .application-info {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .btn-back {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center text-primary mb-4">Application Details</h2>

    <!-- Error Message (if application not found) -->
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo htmlspecialchars($error_message); ?>
        </div>
    <?php endif; ?>

    <!-- Application Info -->
    <div class="application-info">
        <h4 class="mb-3">Applicant Information</h4>
        <p><strong> Name:</strong> <?php echo htmlspecialchars($application['name']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($application['email']); ?></p>
        <p><strong>Phone:</strong> <?php echo htmlspecialchars($application['phone']); ?></p>
        <p><strong>Skills:</strong> <?php echo htmlspecialchars($application['skills']); ?></p>
        <!-- Add more application details here if necessary -->

        <!-- Back Button -->
        <a href="admin.php" class="btn btn-secondary btn-back">Back to Admin Dashboard</a>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

