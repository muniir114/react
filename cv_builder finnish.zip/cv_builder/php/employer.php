<?php
include 'db.php';  // Include your database connection

// Initialize variables
$search_results = [];
$search_message = "";

// Check if the search form has been submitted
if (isset($_POST['search'])) {
    $search_term = trim($_POST['search_term']);  // Get and sanitize the search term
    
    // Query to search for matching first_name, last_name, or skills
    $sql = "SELECT * FROM cvs WHERE (name LIKE ? OR email LIKE ? OR skills LIKE ?)";
    
    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        // If the statement preparation failed, output an error message
        die('MySQL prepare error: ' . $conn->error);
    }
    
    // Sanitize the search term for the LIKE clause
    $search_term_wildcard = "%$search_term%";
    
    // Bind parameters and check for errors
    if (!$stmt->bind_param("sss", $search_term_wildcard, $search_term_wildcard, $search_term_wildcard)) {
        die('Error binding parameters: ' . $stmt->error);
    }

    // Execute the query
    if (!$stmt->execute()) {
        die('Error executing query: ' . $stmt->error);
    }

    // Get the result
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $search_results = $result;  // Store the results for rendering
    } else {
        $search_message = "No results found.";  // Message when no results are found
    }
    
    $stmt->close();  // Close the prepared statement
}

// Handle view CV request via GET
if (isset($_GET['view_cv_id'])) {
    $cv_id = $_GET['view_cv_id'];
    
    // Query to get the CV details
    $cv_sql = "SELECT * FROM cvs WHERE id = ?";
    $cv_stmt = $conn->prepare($cv_sql);
    
    if ($cv_stmt === false) {
        die('MySQL prepare error: ' . $conn->error);
    }
    
    $cv_stmt->bind_param("i", $cv_id);  // Bind the cv_id parameter
    $cv_stmt->execute();  // Execute the query
    $cv_result = $cv_stmt->get_result();
    
    if ($cv_result->num_rows > 0) {
        $cv = $cv_result->fetch_assoc();
    } else {
        $cv = null;
    }
    $cv_stmt->close();  // Close the CV query
}

$conn->close();  // Close the database connection
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer Page</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS (Optional for further customizations) -->
    <style>
        body {
            background-color: #f8f9fa;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .search-form {
            margin-bottom: 20px;
        }
        .pagination {
            justify-content: center;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <h2 class="text-center text-primary">Employer Search Applications</h2>

        <!-- Search Form -->
        <div class="search-form mb-4">
            <form id="searchForm" class="d-flex justify-content-center" action="employer.php" method="POST">
                <input type="text" name="search_term" class="form-control me-2" placeholder="Search by user name or skills" required>
                <button type="submit" name="search" class="btn btn-primary">Search</button>
            </form>
        </div>

        <!-- Search Results Table -->
        <h3>Search Results</h3>
        <div id="resultsContainer">
            <?php if (!empty($search_results)): ?>
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Contact</th>
                            <th>Skills</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($result = $search_results->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($result['name']) ; ?></td>
                                <td><?php echo htmlspecialchars($result['email']); ?></td>
                                <td><?php echo htmlspecialchars($result['skills']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-warning" role="alert">
                    <?php echo $search_message; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS (Required for dynamic behavior and modal functionality) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

