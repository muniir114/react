<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect to login if not logged in
    exit();
}

include 'db.php';

$message = ''; // Initialize message variable

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $new_skill = $_POST['new_skill'];
    $skill_rating = $_POST['skill_rating'];

    $sql = "INSERT INTO skills (user_id, skill_name, skill_rating) VALUES ('$user_id', '$new_skill', '$skill_rating')";
    if ($conn->query($sql) === TRUE) {
        $message = "Skill added successfully!";
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Fetch user's skills for display
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM skills WHERE user_id='$user_id'";
$result = $conn->query($sql);
$skills = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $skills[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skills Progression</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/general.css">

</head>
<body>
<div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h3>Navigation</h3>
            <a href="../index.php">home</a>
            <a href="create_cv.php">Create CV</a>
            <a href="contact.php">Contact</a>
            <a href="#">Skills Progression</a>
            <a href="aboutus.php">About Us</a>
            <a href="logout.php">Logout</a>
        </div>

        <!-- Main Content Area -->
        <div class="main-content">        
            <!-- Skill Form -->
            <h2 class="text-center text-primary mb-4">Skills Progression</h2>      

            <!-- Display Success or Error Message -->
            <?php if ($message): ?>
                <div class="alert alert-<?php echo (strpos($message, 'successfully') !== false) ? 'success' : 'danger'; ?>" role="alert">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form id="skillForm" action="skills_progression.php" method="POST" class="mb-4">
                <div class="mb-3">
                    <label for="new_skill" class="form-label">New Skill</label>
                    <input type="text" class="form-control" id="new_skill" name="new_skill" placeholder="Enter a new skill" required>
                </div>
                <div class="mb-3">
                    <label for="skill_rating" class="form-label">Skill Rating (0-10)</label>
                    <input type="number" class="form-control" id="skill_rating" name="skill_rating" placeholder="Rate your skill (0-10)" min="0" max="10" required>
                </div>
                <button type="submit" class="btn btn-primary">Save Skill</button>
            </form>

            <h3>Your Skills</h3>
            <!-- Skill List -->
            <?php if (count($skills) > 0): ?>
                <ul class="list-group">
                    <?php foreach ($skills as $skill): ?>
                        <li class="list-group-item">
                            <?php echo htmlspecialchars($skill['skill_name']) . " - Rating: " . htmlspecialchars($skill['skill_rating']); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No skills added yet.</p>
            <?php endif; ?>
        </div>

    </div>

    <!-- Footer Section -->
    <footer class="footer">
        <p>&copy; 2024 CV Builder. All rights reserved. Mohamed Osman Abdi</p>
        <div class="footer-icons">
            <a href="https://github.com/turkuai/web-cv-team-4">Github</a>
            <a href="#">Twitter</a>
            <a href="#">Link</a>
            <a href="#">Discord</a>
        </div>
    </footer>

    <!-- Bootstrap JS (Required for dynamic behavior and modal functionality) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
