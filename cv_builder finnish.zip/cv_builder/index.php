<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Builder</title>
    
    <!-- Bootstrap CSS (using the latest version) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/general.css">
 

</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h3>Navigation</h3>
            <a href="#">home</a>
            <a href="php/create_cv.php">Create CV</a>
            <a href="php/contact.php">Contact</a>
            <a href="php/skills_progression.php">Skills Progression</a>
            <a href="php/aboutus.php">About Us</a>
            <a href="php/logout.php">Logout</a>
        </div>

        <!-- Main Content Area -->
        <div class="main-content">
            <h2>Welcome to CV Builder</h2>
            <p >This Application It helps you build professional CVs and resumes with ease.</p>
            <button id="moreInfoBtn" class="btn btn-info">More Info</button>
            <div id="moreInfo" class="mt-3" style="display:none;">
                <p >This Application will help you to build resume or professional cv and make your cv employer to see !</p>
            </div>
        </div>
    </div>

    <!-- Footer Section -->
    <footer class="footer">
        <p>&copy; 2024 CV Builder. All rights reserved. Mohamed Osman Abdi</p>
        <div class="footer-icons">
            <a href="https://github.com/turkuai/web-cv-team-4">Github</a>
            <a href="#">Twitter</a>
            <a href="#">Link</a>
            <a href="#">Discord</a>
        </div>
    </footer>

    <!-- Bootstrap JS (Popper.js and Bootstrap JS) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>

    <!-- Custom JS for interaction -->
    <script>
        document.getElementById("moreInfoBtn").addEventListener("click", function() {
            var moreInfoDiv = document.getElementById("moreInfo");
            if (moreInfoDiv.style.display === "none") {
                moreInfoDiv.style.display = "block";
            } else {
                moreInfoDiv.style.display = "none";
            }
        });
    </script>
</body>
</html>
